# Ansible Playbooks for Cloudera Data Platform

## Requirements

- Python 2.x or 3.x
- [Ansible](http://docs.ansible.com/ansible/intro_installation.html)
- [JMESPath](https://jmespath.org/)

**Do not use Ansible 2.9.0**. This version has an [issue with templating](https://github.com/ansible/ansible/issues/64745) which causes the playbook execution to fail. Instead, use any 2.8.x version or a later 2.9.x version as these are not affected.

## Supported Platforms

### Cloudera Distributions

- Cloudera Manager / CDP-DC 7.1.x
- Cloudera Manager / CDH 6.x
- Cloudera Manager / CDH 5.x (limited support)

### Operating Systems

- Red Hat / CentOS 7.x
- Ubuntu 18.04.04 LTS (Bionic Beaver)

Active development is focused on **CDP Data Center** (CDP-DC) and **CDP Private Cloud** deployments and their respective platform compatibility matrices.

> While these playbooks can be used to deploy CDH 5.x and CDH 6.x environments, it is only possible to install a subset of their supported platform components (i.e JDK and database versions) using this tool.

## Getting Started

For help setting up the playbook, creating configs and deploying clusters, see the [Getting Started](docs/getting-started.md) guide.

## Security

For information on how to deploy secure clusters, check the [Security](docs/security.md)  guide.

## Help!

1. Common issues and their solutions are documented on the [Troubleshooting](docs/troubleshooting.md) page. Check here first.

2. Ask a question in Slack [#proj_cloudera_playbook](https://cloudera.slack.com/archives/CRQQ8CMD4)

## How To Contribute

- If you want to report a **bug** or have a **feature suggestion**, please create a ticket in the [PS JIRA project](https://jira.cloudera.com/projects/PS). If the "Epic Link" field, please choose **Cloudera Playbook V2**. Alternatively, [create an issue](https://help.github.com/en/github/managing-your-work-on-github/creating-an-issue) in GitHub. 

- If you can fix the issue yourself, please [fork the repository](https://help.github.com/en/github/getting-started-with-github/fork-a-repo), commit the fix to your own copy and then [create a pull request](https://help.github.com/en/github/collaborating-with-issues-and-pull-requests/creating-a-pull-request-from-a-fork). 

- If you have general feedback, let us know in Slack [#proj_cloudera_playbook](https://cloudera.slack.com/archives/CRQQ8CMD4)!

## License

TODO
