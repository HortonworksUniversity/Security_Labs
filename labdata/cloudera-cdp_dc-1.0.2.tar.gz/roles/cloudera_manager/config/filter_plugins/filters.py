#!/usr/bin/python

class FilterModule(object):

  def filters(self):
    return {
      'filter_null_configs': self.filter_null_configs
    }

  def filter_null_configs(self, configs, existing_configs):
    filtered_configs = dict(configs)
    for item, value in configs.items():
      if item not in existing_configs and not value:
        del filtered_configs[item]
    return filtered_configs
