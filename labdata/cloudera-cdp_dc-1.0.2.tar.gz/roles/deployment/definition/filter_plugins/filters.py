#!/usr/bin/python

import json
import re

class FilterModule(object):

  def filters(self):
    return {
        'extract_products_from_manifests': self.extract_products_from_manifests,
        'format_database_type': self.format_database_type,
        'get_product_version': self.get_product_version,
        'get_major_version': self.get_major_version,
        'append_database_port': self.append_database_port,
        'default_database_port': self.default_database_port
    }

  def extract_products_from_manifests(self, manifests):
    products = dict()
    for manifest in manifests:
      for parcel in manifest['parcels']:
        # take first parcel, strip off OS name and file extension
        parcel_name = re.sub("-[a-z0-9]+\.parcel$", "", str(parcel['parcelName']))
        # the product name is before the first dash
        product = parcel_name[:parcel_name.index("-")]
        if product not in products:
          # the version string is everything after the first dash
          version = parcel_name[parcel_name.index("-")+1:]
          products[product] = version
    return products

  def format_database_type(self, database_type, service_type=None):
    if database_type == "mariadb":
      return "mysql"
    return database_type.lower()

  def get_product_version(self, products, product_name):
    for product in products:
      if product['product'] == product_name:
        version = product['version']
        return version[:version.index('-')] if "-" in version else version

  def get_major_version(self, products, product_name):
    version = self.get_product_version(products, product_name)
    if version:
      return version.split('.')[0]

  def append_database_port(self, database_host, database_port=None):
    if ":" not in database_host and database_port:
      return database_host + ":" + database_port
    return database_host

  def default_database_port(self, database_type):
    if database_type == "postgresql":
      return 5432
    if database_type == "mysql" or database_type == "mariadb":
      return 3306
    return None
